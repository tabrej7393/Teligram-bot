import telebot
import requests

BOT_TOKEN = "8124183202:AAEkopyG8g5CAC6CNyZO3eIQanJM562fB9A"
API_URL = "https://demon.taitanx.workers.dev/?mobile="

bot = telebot.TeleBot(BOT_TOKEN)

credits = {}

@bot.message_handler(commands=['start'])
def start(msg):
    uid = msg.from_user.id

    if uid not in credits:
        credits[uid] = 10

    text = (
        "👋 Welcome to Technical Tabbo 💖 Bot\n\n"
        "Send only *mobile number* (without country code)\n\n"
        f"🔵 Your Credits: {credits[uid]}\n\n"
        "Contact Admin ☎️ @tabrej12\n\n"
        "🔴 Credit by TABBO INFORMATION"
    )

    bot.send_message(msg.chat.id, text, parse_mode="Markdown")


@bot.message_handler(func=lambda m: True)
def handle_number(msg):
    uid = msg.from_user.id
    number = msg.text.strip()

    if not number.isdigit():
        bot.reply_to(msg, "❌ Only numbers allowed!")
        return

    if credits.get(uid, 0) <= 0:
        bot.reply_to(msg, "❌ No credits left! Contact admin.")
        return

    api = API_URL + number
    result = requests.get(api).text

    credits[uid] -= 1

    bot.reply_to(
        msg,
        f"✅ API Result:\n{result}\n\nRemaining Credits: {credits[uid]}"
    )


bot.infinity_polling()
